const express = require('express');
const controllerTela = require('./controllers/controller');
const controllersCrud = require('./controllers/controllersCrud');
const controllersRelatorio = require ('./controllers/controllersRelatorio');
const app = express();

// Configura o EJS como mecanismo de visualização
app.set('view engine', 'ejs');

app.get ('/', controllerTela.getTela);
app.get ('/index', controllersCrud.getAllUsers);
app.get('/add', (req,res) => res.render('add'));
app.post('/add', controllersCrud.addUser);
app.get('/edit/:id', controllersCrud.getUserById);
app.post('/edit/:id', controllersCrud.updateUser);
app.get('/dell/:id', controllersCrud.getdeleteByUser);
app.post('/dell/:id', controllersCrud.deleteUser);

app.get('/relatorio',controllersRelatorio.getAllUsers);
app.get('/relatorio/pdf',controllersRelatorio.generatePDF);


// Iniciar o servidor
app.listen(2001, () => {
    console.log('http://localhost:2001');
});