const User = require('../models/modelsCrud');

exports.getAllUsers = (req, res) => {
        User.getAllUsers((users) => {
         res.render('index', {users});
     });
};

exports.getUserById = (req, res) => {
    const userId = req.params.id;
    User.getUserById(userId, (user) =>{
        res.render('edit', {user});
    });
};

exports.getdeleteByUser = (req, res) => {
    const userId = req.params.id;
    User.getUserById(userId, (user) =>{
        res.render('dell', { user });
    });
};

exports.addUser = (req, res) => {
    const newUser = {
        name: req.body.name,
        email: req.body.email,
        fone : req.body.fone,
        endereco : req.body.endereco
    };
    User.addUser(newUser, () => {
        res.redirect('/index');
    });
};


exports.updateUser = (req, res) => {
    const userId = req.params.id;
    const updatedUser = {
        name: req.body.name,
        email: req.body.email,
        fone : req.body.fone,
        endereco : req.body.endereco
    };
    User.updateUser(userId, updatedUser, () => {
        res.redirect('/index');
    });
};

exports.deleteUser = (req, res) => {
    const userId = req.params.id;
    User.deleteUser(userId, () => {
        res.redirect('/');
    });
};

exports.loginUser = (req, res) => {
    const { username, password} = req.body;
    User.getUserByUsername(username, (user) => {
        if (user && user.pass === password) {
            res.redirect('/')
        } else {
            res.render('login', { loginFalhou: true });
        }
    })
};