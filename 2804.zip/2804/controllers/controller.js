exports.getTela = (req,res) => {
    res.render('menu');

};
